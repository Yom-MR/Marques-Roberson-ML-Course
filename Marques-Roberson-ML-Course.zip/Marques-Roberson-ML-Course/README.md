# Marques Roberson – AI in Healthcare Course Portfolio

Welcome to my course portfolio for **ITAI‑4375: Artificial Intelligence in Healthcare** (Houston Community College, Spring 2026).  This repository collects the labs and assignments completed during the semester.  All materials are organized into clear folders with explanatory README files and accompanying Jupyter notebooks so that instructors and peers can easily review my work.

## About Me
My name is Marques Roberson, and I am fascinated by the intersection of technology and medicine.  I enrolled in this course to deepen my understanding of machine learning and its applications in healthcare—from automating routine tasks to supporting complex clinical decisions.  This portfolio showcases my learning journey.

## Repository Structure
The repository is organized into two main directories:

- **Labs/** – Hands‑on exercises that reinforce course concepts.
- **Assignments/** – Written and computational assignments exploring medical terminology, data analysis, emerging AI tools, diagnostic studies, and social determinants of health.

Each subfolder contains a concise README and a Jupyter notebook capturing the work.

## Completed Work

| Folder | Description |
|-------|-------------|
| `Labs/Lab1` | *AI in Healthcare: A Glossary of Key Terms*.  An alphabetical glossary defining foundational AI concepts (e.g., algorithmic bias, explainable AI, federated learning) with healthcare examples and their significance. |
| `Assignments/Assignment1` | *Medical Terminology*.  Plain‑language explanations of complex medical terms, each with context and importance. |
| `Assignments/Assignment2` | *Healthcare Datasets*.  Calculation of average age and heart rate from a sample patient dataset to practice basic descriptive statistics. |
| `Assignments/Assignment3` | *Clinical Decision Support Systems*.  An essay envisioning the future of AI‑powered clinical decision support in the next decade, balancing benefits and challenges. |
| `Assignments/Assignment4` | *Evaluating Results from a Diagnostic Study*.  A summary and critique of the fast‑RSOM test for early microvascular disease detection, including discussion of sensitivity, specificity and clinical use cases. |
| `Assignments/Assignment5` | *(Placeholder)*.  This folder remains empty because no Assignment 5 was provided.  It exists for numbering consistency. |
| `Assignments/Assignment6` | *Exploring Traditional Health Data*.  A reflection on social determinants of health (SDOH), their examples, potential benefits and ethical concerns when integrating them into healthcare. |

## How to Run the Notebooks
Each assignment and lab is provided as a Jupyter notebook composed of markdown cells.  To view or edit a notebook:

1. Clone or download this repository.
2. Open the `.ipynb` file of interest using JupyterLab, VS Code, or another compatible environment.

These notebooks contain narrative explanations rather than executable code; they serve as a convenient format for reading and commenting on the work.

Feel free to explore the materials and reach out if you have any questions!
